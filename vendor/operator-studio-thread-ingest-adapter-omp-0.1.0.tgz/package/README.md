# @operator-studio/thread-ingest-adapter-omp

Data-only local OMP transcript manifest and strict JSONL parser for use with `@operator-studio/thread-ingest-core`. It inventories local data and materializes only explicitly selected sessions through the host-controlled adapter contract.

It does not make network requests, obtain credentials, execute processes, control terminals, open browsers, or upload transcript data.

Licensed under Apache-2.0. See `LICENSE` and `NOTICE` in this package.
