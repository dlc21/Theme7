# @operator-studio/thread-ingest-core

Data-only TypeScript contracts for local transcript inventory and explicit normalization. It supplies provider manifests, bounded scanning over a host-injected filesystem/config interface, closed normalized thread types, safe inventory projections, and fixture/conformance utilities.

This package does not make network requests, obtain or store credentials, execute processes, control terminals, open browsers, or upload transcript data. The embedding host must explicitly grant local access and owns all consent, policy, transport, and authorization decisions.

Licensed under Apache-2.0. See `LICENSE` and `NOTICE` in this package.
