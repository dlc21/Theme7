# Theme7 application assets

This directory contains Theme7's built-in visual language, onboarding, starter, and OMP adapter. These assets are part of the Theme7 application; they are not a selectable theme or a separate distribution.

OMP remains a separate operator-supplied CLI. Theme7 does not install OMP, authenticate it, or read its credentials. Install and authenticate OMP through its official supported flow, then start Theme7 normally.

The package test verifies the bounded application assets, adapter behavior, and exact OMP session-identity handshake used by the unified application.
